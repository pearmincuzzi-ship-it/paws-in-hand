
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Using the provided user text as the ultimate source of truth
const RESEARCH_CONTEXT = `
  老年犬定义：8岁起步，8-12岁初老，12岁+老年/超老。大型犬衰老快（6-8岁老年）。
  换算公式：16 * ln(狗龄) + 31。
  利物浦研究五大问题：体重(35%)、肌肉骨骼(33%)、牙科(31%)、皮肤(28%)、消化(22%)。
  行为变化：运动量下降（肌肉/疼痛）、睡眠紊乱（认知障碍）、饮食挑食（口腔/过敏）、乱大小便（生理原因）、分离焦虑（感官退化）、社交退缩（精力下降）、情绪反应迟钝（反射弧长）、易受惊吓攻击。
  护理核心：定期体检、主动管理体重/牙科、多模式镇痛、防滑环境。
`;

export const getBehaviorConsultation = async (userQuery: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `
        你是一个专门服务老年犬的行为专家。请基于以下特定的科学资料库来回答用户的问题。
        
        【资料库】：${RESEARCH_CONTEXT}
        
        用户的问题：${userQuery}
        
        要求：
        1. 必须体现《默克兽医手册》或利物浦大学研究的科学背景。
        2. 语气必须温暖且具备极高的同理心。
        3. 给出3条具体的行动方案。
        4. 结尾必须署名：“以上内容由 乖乖狗幼儿园整理 行为咨询团队提供”。
        5. 语言为中文。
      `,
      config: {
        maxOutputTokens: 800,
        temperature: 0.4,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Consultation Error:", error);
    return "抱歉，咨询系统目前繁忙，请稍后再试。";
  }
};

// Daily presentation logic based on core facts
export const getDailyPresentation = async (fact: {title: string, content: string, source: string}) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `
        基于以下科学事实，为老年犬主人撰写今天的日历知识卡片。
        标题：${fact.title}
        事实：${fact.content}
        来源：${fact.source}
        
        请重新包装内容，使其更具每日阅读的“仪式感”，并补充一条极其细微的观察建议。不超过100字。
      `,
    });
    return response.text;
  } catch (error) {
    return `${fact.title}: ${fact.content}\n\n来源：${fact.source}`;
  }
};
