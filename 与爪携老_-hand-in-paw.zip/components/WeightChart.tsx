
import React from 'react';
import { DogLog, LogType } from '../types';

interface WeightChartProps {
  logs: DogLog[];
}

export const WeightChart: React.FC<WeightChartProps> = ({ logs }) => {
  const weightLogs = logs
    .filter(log => log.type === LogType.WEIGHT && log.value)
    .map(log => ({
      date: new Date(log.date),
      weight: parseFloat(log.value!),
      originalDate: log.date
    }))
    .sort((a, b) => a.date.getTime() - b.date.getTime());

  if (weightLogs.length < 2) {
    return (
      <div className="bg-stone-50 border border-stone-200 rounded-[2rem] p-6 text-center">
        <p className="text-xs text-stone-400 font-medium">需要至少 2 条体重记录来生成趋势图表</p>
      </div>
    );
  }

  const weights = weightLogs.map(l => l.weight);
  const minWeight = Math.min(...weights);
  const maxWeight = Math.max(...weights);
  const weightRange = maxWeight - minWeight || 1;
  const padding = weightRange * 0.2;

  const chartMin = minWeight - padding;
  const chartMax = maxWeight + padding;
  const chartRange = chartMax - chartMin;

  const width = 300;
  const height = 120;

  const points = weightLogs.map((log, i) => {
    const x = (i / (weightLogs.length - 1)) * width;
    const y = height - ((log.weight - chartMin) / chartRange) * height;
    return { x, y, weight: log.weight, date: log.originalDate };
  });

  const pathD = points.reduce((acc, point, i) => {
    return i === 0 ? `M ${point.x} ${point.y}` : `${acc} L ${point.x} ${point.y}`;
  }, '');

  const areaD = `${pathD} L ${points[points.length - 1].x} ${height} L ${points[0].x} ${height} Z`;

  return (
    <div className="bg-white border border-stone-100 rounded-[2rem] p-6 shadow-sm overflow-hidden">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h4 className="text-sm font-bold text-stone-800">体重变化趋势</h4>
          <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">Weight Tracker</p>
        </div>
        <div className="text-right">
          <span className="text-xl font-black text-green-600 tabular-nums">
            {weightLogs[weightLogs.length - 1].weight}
          </span>
          <span className="text-[10px] font-bold text-stone-400 ml-1">KG</span>
        </div>
      </div>

      <div className="relative pt-2">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible">
          {/* Gradients */}
          <defs>
            <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#16a34a" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#16a34a" stopOpacity="0" />
            </linearGradient>
          </defs>

          {/* Grid lines (min/max) */}
          <line x1="0" y1="0" x2={width} y2="0" stroke="#f5f5f4" strokeWidth="1" strokeDasharray="4" />
          <line x1="0" y1={height} x2={width} y2={height} stroke="#f5f5f4" strokeWidth="1" strokeDasharray="4" />

          {/* Area */}
          <path d={areaD} fill="url(#areaGradient)" />

          {/* Line */}
          <path
            d={pathD}
            fill="none"
            stroke="#16a34a"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="animate-in fade-in duration-1000"
          />

          {/* Points */}
          {points.map((point, i) => (
            <g key={i}>
              <circle
                cx={point.x}
                cy={point.y}
                r="4"
                fill="white"
                stroke="#16a34a"
                strokeWidth="2"
              />
              {/* Labels for start and end */}
              {(i === 0 || i === points.length - 1) && (
                <text
                  x={point.x}
                  y={point.y - 8}
                  textAnchor={i === 0 ? 'start' : 'end'}
                  fontSize="8"
                  fontWeight="bold"
                  fill="#78716c"
                >
                  {point.weight}
                </text>
              )}
            </g>
          ))}
        </svg>
      </div>
      
      <div className="flex justify-between mt-2">
        <span className="text-[8px] font-bold text-stone-300 uppercase tracking-tighter">
          {weightLogs[0].originalDate}
        </span>
        <span className="text-[8px] font-bold text-stone-300 uppercase tracking-tighter">
          {weightLogs[weightLogs.length - 1].originalDate}
        </span>
      </div>
    </div>
  );
};
