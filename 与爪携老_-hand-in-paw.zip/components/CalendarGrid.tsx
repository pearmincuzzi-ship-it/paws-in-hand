
import React, { useState } from 'react';
// Fix: Removed incorrect export member LOG_TYPE_CONFIG from '../types'
import { DogLog } from '../types';

interface CalendarGridProps {
  logs: DogLog[];
  onDateSelect: (date: string) => void;
  selectedDate: string;
}

export const CalendarGrid: React.FC<CalendarGridProps> = ({ logs, onDateSelect, selectedDate }) => {
  const [currentDate, setCurrentDate] = useState(new Date());

  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
  
  const monthNames = ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"];
  const weekDays = ["日", "一", "二", "三", "四", "五", "六"];

  const prevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));

  const isToday = (day: number) => {
    const today = new Date();
    return today.getDate() === day && today.getMonth() === currentDate.getMonth() && today.getFullYear() === currentDate.getFullYear();
  };

  const getLogsForDate = (day: number) => {
    const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return logs.filter(log => log.date === dateStr);
  };

  return (
    <div className="bg-white rounded-3xl p-4 shadow-sm border border-stone-100 mx-4 mt-4">
      <div className="flex justify-between items-center mb-6">
        <button onClick={prevMonth} className="p-2 hover:bg-stone-50 rounded-full text-stone-400">←</button>
        <h2 className="font-bold text-stone-700">{currentDate.getFullYear()}年 {monthNames[currentDate.getMonth()]}</h2>
        <button onClick={nextMonth} className="p-2 hover:bg-stone-50 rounded-full text-stone-400">→</button>
      </div>

      <div className="grid grid-cols-7 mb-2">
        {weekDays.map(day => (
          <div key={day} className="text-center text-[10px] font-bold text-stone-400 uppercase">{day}</div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-1">
        {Array.from({ length: firstDayOfMonth }).map((_, i) => (
          <div key={`empty-${i}`} className="h-12" />
        ))}
        {Array.from({ length: daysInMonth }).map((_, i) => {
          const day = i + 1;
          const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          const isSelected = selectedDate === dateStr;
          const dateLogs = getLogsForDate(day);

          return (
            <button
              key={day}
              onClick={() => onDateSelect(dateStr)}
              className={`h-12 rounded-xl flex flex-col items-center justify-center relative transition-all duration-200 border-2
                ${isSelected ? 'bg-orange-50 border-orange-200' : 'bg-transparent border-transparent hover:bg-stone-50'}
                ${isToday(day) && !isSelected ? 'text-orange-600 font-bold' : ''}
              `}
            >
              <span className="text-sm">{day}</span>
              <div className="flex gap-0.5 mt-1">
                {dateLogs.slice(0, 3).map(log => (
                  <div key={log.id} className="w-1 h-1 rounded-full bg-orange-400" />
                ))}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
