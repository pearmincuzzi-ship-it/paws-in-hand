
import React from 'react';
import { ViewMode } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeView: ViewMode;
  setActiveView: (view: ViewMode) => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeView, setActiveView }) => {
  return (
    <div className="flex flex-col h-screen max-w-md mx-auto bg-white shadow-xl relative overflow-hidden">
      {/* Header */}
      <header className="px-6 py-4 bg-white border-b border-stone-100 shrink-0">
        <h1 className="text-xl font-bold text-stone-800 flex items-center gap-2">
          <span className="text-2xl">🐾</span> 与爪携老
        </h1>
        <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">Hand in Paw • Senior Care</p>
      </header>

      {/* Content Area */}
      <main className="flex-1 overflow-y-auto hide-scrollbar pb-24">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/80 backdrop-blur-md border-t border-stone-100 px-6 py-3 flex justify-between items-center z-50">
        <NavItem 
          active={activeView === 'CALENDAR'} 
          onClick={() => setActiveView('CALENDAR')} 
          icon="📅" 
          label="日历" 
        />
        <NavItem 
          active={activeView === 'LOGS'} 
          onClick={() => setActiveView('LOGS')} 
          icon="✍️" 
          label="记录" 
        />
        <NavItem 
          active={activeView === 'KNOWLEDGE'} 
          onClick={() => setActiveView('KNOWLEDGE')} 
          icon="📚" 
          label="知识" 
        />
      </nav>
    </div>
  );
};

const NavItem = ({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: string, label: string }) => (
  <button 
    onClick={onClick}
    className={`flex flex-col items-center gap-1 transition-all duration-200 ${active ? 'text-orange-600 scale-110' : 'text-stone-400'}`}
  >
    <span className="text-xl">{icon}</span>
    <span className="text-[10px] font-bold uppercase tracking-wider">{label}</span>
  </button>
);
