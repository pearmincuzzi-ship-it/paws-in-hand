
import React, { useState } from 'react';
// Fix: Separated types and constants imports
import { LogType, DogLog } from '../types';
import { LOG_TYPE_CONFIG } from '../constants';
import { WeightChart } from './WeightChart';

interface LogFormProps {
  date: string;
  onSave: (log: DogLog) => void;
  onDelete: (id: string) => void;
  logs: DogLog[];
}

export const LogForm: React.FC<LogFormProps> = ({ date, onSave, onDelete, logs }) => {
  const [type, setType] = useState<LogType>(LogType.NOTE);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [value, setValue] = useState('');
  const [showForm, setShowForm] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;
    
    onSave({
      id: Date.now().toString(),
      date,
      type,
      title,
      description: desc,
      value: type === LogType.WEIGHT ? value : undefined
    });

    setTitle('');
    setDesc('');
    setValue('');
    setShowForm(false);
  };

  const dayLogs = logs.filter(log => log.date === date);
  const hasWeights = logs.some(log => log.type === LogType.WEIGHT);

  return (
    <div className="px-6 py-4 space-y-6">
      {/* Visual Analysis Section */}
      {hasWeights && (
        <section className="animate-in fade-in slide-in-from-top-4 duration-500">
          <WeightChart logs={logs} />
        </section>
      )}

      <div className="flex justify-between items-center">
        <h3 className="text-lg font-bold text-stone-800">
          {date} <span className="text-stone-400 font-normal">记录</span>
        </h3>
        <button 
          onClick={() => setShowForm(!showForm)}
          className="text-sm font-bold text-orange-600 bg-orange-50 px-4 py-2 rounded-xl active:scale-95 transition-all"
        >
          {showForm ? '取消' : '+ 添加记录'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-stone-50 p-6 rounded-[2.5rem] space-y-5 border border-stone-200 animate-in zoom-in-95 duration-300 shadow-inner">
          <div className="grid grid-cols-5 gap-2">
            {(Object.keys(LOG_TYPE_CONFIG) as LogType[]).map(t => (
              <button
                key={t}
                type="button"
                onClick={() => setType(t)}
                className={`flex flex-col items-center p-2.5 rounded-2xl transition-all duration-300 ${type === t ? 'bg-stone-900 text-white shadow-xl scale-105' : 'bg-white text-stone-400 border border-stone-100'}`}
              >
                <span className="text-xl">{LOG_TYPE_CONFIG[t].icon}</span>
                <span className="text-[9px] mt-1 font-black whitespace-nowrap uppercase tracking-tighter">{LOG_TYPE_CONFIG[t].label}</span>
              </button>
            ))}
          </div>

          <div className="space-y-3">
            <input 
              type="text" 
              placeholder="记录标题 (如: 晚餐食欲不佳)"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-white px-5 py-3 rounded-2xl text-sm border border-stone-200 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all"
              required
            />

            {type === LogType.WEIGHT && (
              <div className="relative">
                <input 
                  type="number" 
                  step="0.1"
                  placeholder="当前体重"
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                  className="w-full bg-white px-5 py-3 rounded-2xl text-sm border border-stone-200 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all"
                />
                <span className="absolute right-5 top-1/2 -translate-y-1/2 text-[10px] font-bold text-stone-400">KG</span>
              </div>
            )}

            <textarea 
              placeholder="详细描述或备注..."
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
              className="w-full bg-white px-5 py-3 rounded-2xl text-sm border border-stone-200 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 h-28 resize-none"
            />
          </div>

          <button 
            type="submit"
            className="w-full bg-orange-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-orange-600/20 hover:bg-orange-500 active:scale-95 transition-all"
          >
            保存今日记录
          </button>
        </form>
      )}

      <div className="space-y-4 pb-8">
        {dayLogs.length === 0 ? (
          <div className="text-center py-16 bg-stone-50/50 rounded-[2.5rem] border border-dashed border-stone-200">
            <span className="text-5xl block mb-4 opacity-50">🦴</span>
            <p className="text-sm font-medium text-stone-400 px-12">该日期尚无记录。坚持记录能帮助兽医更准确地判断爱犬的健康状态。</p>
          </div>
        ) : (
          dayLogs.map(log => (
            <div key={log.id} className="bg-white p-5 rounded-[2rem] border border-stone-100 shadow-sm relative group hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{LOG_TYPE_CONFIG[log.type].icon}</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest ${LOG_TYPE_CONFIG[log.type].color}`}>
                    {LOG_TYPE_CONFIG[log.type].label}
                  </span>
                </div>
                <button 
                  onClick={() => onDelete(log.id)}
                  className="w-7 h-7 flex items-center justify-center rounded-full bg-stone-50 text-stone-300 hover:text-red-500 hover:bg-red-50 transition-all"
                >
                  ✕
                </button>
              </div>
              <h4 className="font-black text-stone-800 text-lg leading-tight">{log.title}</h4>
              {log.value && (
                <div className="flex items-baseline gap-1 mt-2 text-green-600">
                  <span className="text-xl font-black">{log.value}</span>
                  <span className="text-[10px] font-bold uppercase">kg</span>
                </div>
              )}
              <p className="text-sm text-stone-500 mt-2 leading-relaxed whitespace-pre-wrap">{log.description}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
