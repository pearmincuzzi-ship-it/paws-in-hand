
import React, { useState, useEffect } from 'react';
import { SENIOR_KNOWLEDGE_BASE, PROVIDER_CREDIT } from '../constants';
import { getBehaviorConsultation, getDailyPresentation } from '../services/geminiService';
import { AgeConverter } from './AgeConverter';

export const KnowledgeBase: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [dailyCard, setDailyCard] = useState<string | null>(null);
  const [consultationResult, setConsultationResult] = useState<string | null>(null);
  const [showConsultInput, setShowConsultInput] = useState(false);
  const [userQuestion, setUserQuestion] = useState('');
  const [dayOfYear, setDayOfYear] = useState(0);

  const todayStr = new Date().toISOString().split('T')[0];

  useEffect(() => {
    const fetchDailyCard = async () => {
      const date = new Date();
      const start = new Date(date.getFullYear(), 0, 0);
      const diff = (date.getTime() - start.getTime()) + ((start.getTimezoneOffset() - date.getTimezoneOffset()) * 60 * 1000);
      const oneDay = 1000 * 60 * 60 * 24;
      const day = Math.floor(diff / oneDay);
      setDayOfYear(day);

      const cached = localStorage.getItem(`daily_card_${todayStr}`);
      if (cached) {
        setDailyCard(cached);
        return;
      }

      // Rotate through facts based on day of year to ensure variety
      const factIndex = day % SENIOR_KNOWLEDGE_BASE.length;
      const fact = SENIOR_KNOWLEDGE_BASE[factIndex];
      
      const presented = await getDailyPresentation(fact);
      if (presented) {
        setDailyCard(presented);
        localStorage.setItem(`daily_card_${todayStr}`, presented);
      }
    };

    fetchDailyCard();
  }, [todayStr]);

  const handleConsultation = async () => {
    if (!userQuestion.trim()) return;
    setLoading(true);
    const result = await getBehaviorConsultation(userQuestion);
    setConsultationResult(result);
    setLoading(false);
  };

  return (
    <div className="px-6 py-8 space-y-10 animate-in fade-in duration-700">
      {/* Age Converter Tool */}
      <AgeConverter />

      {/* Daily Knowledge Card */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <div className="flex flex-col">
            <h3 className="text-xl font-bold text-stone-800 tracking-tight">每日科学共识</h3>
            <span className="text-[10px] text-orange-600 font-bold tracking-widest uppercase">Day {dayOfYear} / 365</span>
          </div>
          <div className="flex flex-col items-end">
             <span className="text-[10px] font-bold text-stone-400 bg-stone-50 px-2 py-0.5 rounded border border-stone-100 uppercase tracking-widest">Hand in Paw</span>
             <span className="text-[9px] text-stone-300 mt-1 font-medium">{todayStr}</span>
          </div>
        </div>
        
        <div className="relative group">
          <div className="absolute inset-0 bg-orange-100/50 rounded-[2.5rem] rotate-1 scale-105 group-hover:rotate-0 transition-transform duration-500"></div>
          <div className="relative p-8 bg-white border border-stone-100 rounded-[2.5rem] shadow-xl shadow-stone-200/50 min-h-[340px] flex flex-col justify-between">
            <div>
              <div className="text-4xl mb-6">📅</div>
              {dailyCard ? (
                <div className="prose prose-stone">
                  <p className="text-base text-stone-700 leading-relaxed font-medium whitespace-pre-wrap">
                    {dailyCard}
                  </p>
                </div>
              ) : (
                <div className="space-y-3 animate-pulse">
                  <div className="h-4 bg-stone-100 rounded w-3/4"></div>
                  <div className="h-4 bg-stone-100 rounded w-full"></div>
                  <div className="h-4 bg-stone-100 rounded w-1/2"></div>
                </div>
              )}
            </div>
            
            <div className="mt-8 pt-4 border-t border-stone-50 flex items-center justify-between">
              <span className="text-[10px] text-stone-300 font-bold uppercase tracking-tighter italic">Science-Based Care</span>
              <span className="text-[10px] text-stone-500 font-bold bg-stone-50 px-3 py-1 rounded-full border border-stone-100">{PROVIDER_CREDIT}</span>
            </div>
          </div>
        </div>
      </section>

      {/* Behavior Consultation Section */}
      <section className="space-y-4">
        {!showConsultInput ? (
          <button 
            onClick={() => setShowConsultInput(true)}
            className="w-full bg-stone-900 text-white py-6 rounded-[2.5rem] font-bold shadow-2xl shadow-stone-900/20 active:scale-95 transition-all flex items-center justify-center gap-3 overflow-hidden group"
          >
            <span className="text-xl group-hover:animate-bounce">🐾</span>
            <span className="text-lg">行为咨询入口</span>
            <div className="absolute top-0 right-0 w-24 h-24 bg-white/5 rounded-full blur-2xl -mr-12 -mt-12"></div>
          </button>
        ) : (
          <div className="bg-stone-50 p-6 rounded-[2.5rem] border border-stone-200 animate-in slide-in-from-bottom-4 duration-500">
            <h4 className="text-stone-800 font-bold mb-4 flex items-center gap-2">
              <span className="text-orange-600">✦</span> 行为专家咨询
            </h4>
            <textarea 
              value={userQuestion}
              onChange={(e) => setUserQuestion(e.target.value)}
              placeholder="请输入您观察到的行为改变..."
              className="w-full bg-white border border-stone-200 rounded-2xl p-4 text-sm focus:outline-none focus:border-orange-500 h-32 mb-4 resize-none"
            />
            <div className="flex gap-2">
               <button 
                onClick={() => setShowConsultInput(false)}
                className="flex-1 py-3.5 rounded-2xl text-stone-500 font-bold text-sm bg-stone-200"
              >
                关闭
              </button>
              <button 
                onClick={handleConsultation}
                disabled={loading}
                className="flex-[2] bg-orange-600 text-white py-3.5 rounded-2xl font-bold text-sm shadow-lg shadow-orange-600/20 active:scale-95 disabled:opacity-50"
              >
                {loading ? '咨询中...' : '发送咨询'}
              </button>
            </div>

            {consultationResult && (
              <div className="mt-6 p-5 bg-white rounded-2xl border border-stone-100 text-sm text-stone-700 leading-relaxed whitespace-pre-wrap animate-in fade-in duration-500 shadow-sm border-l-4 border-l-orange-500">
                {consultationResult}
              </div>
            )}
          </div>
        )}
      </section>

      {/* Footer Credit */}
      <div className="text-center pt-8 border-t border-stone-100 mx-4">
        <p className="text-[10px] text-stone-400 font-bold tracking-[0.2em] mb-2 uppercase">Knowledge Source</p>
        <p className="text-xs text-stone-600 font-extrabold">{PROVIDER_CREDIT}</p>
        <p className="text-[9px] text-stone-300 mt-4 leading-relaxed px-6 italic">
          知识库基于默克兽医手册、WSAVA、利物浦大学老年犬研究。
        </p>
      </div>
    </div>
  );
};
