
import React, { useState, useEffect } from 'react';

export const AgeConverter: React.FC = () => {
  const [dogAge, setDogAge] = useState<string>('8');
  const [humanAge, setHumanAge] = useState<number | null>(null);

  useEffect(() => {
    const age = parseFloat(dogAge);
    if (age > 0) {
      // Formula: 16 * ln(dog_age) + 31
      const result = 16 * Math.log(age) + 31;
      setHumanAge(Math.round(result * 10) / 10);
    } else {
      setHumanAge(null);
    }
  }, [dogAge]);

  const getStage = (age: number) => {
    if (age < 45) return { label: '壮年期', color: 'text-green-400' };
    if (age < 60) return { label: '初老期', color: 'text-orange-400' };
    return { label: '高龄期', color: 'text-red-400' };
  };

  return (
    <div className="bg-stone-900 rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden group">
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold flex items-center gap-2">
            <span className="text-orange-500">🧬</span> 科学龄换算器
          </h3>
          <span className="text-[10px] font-bold text-stone-500 uppercase tracking-widest">DNA Methylation Formula</span>
        </div>

        <div className="flex items-end gap-4 mb-8">
          <div className="flex-1">
            <label className="block text-[10px] font-bold text-stone-500 uppercase mb-2 tracking-tighter">狗狗物理年龄 (岁)</label>
            <input 
              type="number" 
              step="0.5"
              min="0.1"
              value={dogAge}
              onChange={(e) => setDogAge(e.target.value)}
              className="w-full bg-white/5 border-b-2 border-stone-700 focus:border-orange-500 py-2 text-3xl font-bold outline-none transition-colors"
            />
          </div>
          <div className="text-4xl text-stone-700 font-light mb-2">≈</div>
          <div className="flex-1 text-right">
            <label className="block text-[10px] font-bold text-stone-500 uppercase mb-2 tracking-tighter">对应人类年龄</label>
            <div className="text-5xl font-black text-orange-500 tabular-nums">
              {humanAge || '--'}
            </div>
          </div>
        </div>

        {humanAge && (
          <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 backdrop-blur-sm">
            <div className="flex flex-col">
              <span className="text-[10px] text-stone-500 font-bold uppercase">生命阶段</span>
              <span className={`text-lg font-bold ${getStage(humanAge).color}`}>
                {getStage(humanAge).label}
              </span>
            </div>
            <p className="text-[10px] text-stone-400 italic max-w-[140px] text-right leading-tight">
              该公式基于加州大学圣地亚哥分校对拉布拉多的遗传学研究。
            </p>
          </div>
        )}
      </div>

      {/* Background Glow */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-orange-600/10 rounded-full blur-3xl -mr-10 -mt-10"></div>
    </div>
  );
};
