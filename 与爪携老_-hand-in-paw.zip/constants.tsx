
import { LogType } from './types';

export const PROVIDER_CREDIT = "乖乖狗幼儿园整理";

// Themed structure to ensure 365 unique angles derived from the source text
export const KNOWLEDGE_THEMES = [
  {
    category: "老龄定义与科学",
    facts: [
      "8岁是普遍认可的老年起点，但8-12岁属于‘初老期’。",
      "12岁后被定义为‘高龄期’或‘超老期’（Super Senior）。",
      "大型犬（22.7kg以上）衰老更快，6岁可能就进入老年阶段。",
      "基于DNA甲基化的换算公式：16 * ln(狗狗年龄) + 31 = 人类年龄。",
      "小型犬衰老较慢，通常在14岁左右才真正进入高龄阶段。",
      "狗狗寿命的最后1/4通常被定义为老年期。"
    ]
  },
  {
    category: "利物浦大学研究发现",
    facts: [
      "利物浦研究指出，35%的老年犬面临体重相关问题（超重或消瘦）。",
      "33%的老年犬患有肌肉骨骼问题，表现为起身困难或僵硬。",
      "31%的老年犬有牙周病，这会直接影响其整体食欲和心脏健康。",
      "28%的老年犬有皮肤肿块或感染问题，需定期全身触摸检查。",
      "22%的老年犬有消化系统敏感，表现为慢性呕吐或腹泻。",
      "兽医发现大型犬如拉布拉多通常在12岁左右进入显著老龄化。"
    ]
  },
  {
    category: "行为与心理变化",
    facts: [
      "肌肉力量下降和关节疼痛会让曾经的运动健将变得像‘乌龟’一样慢。",
      "8岁后的半年内，狗狗对游戏和指令的兴趣可能出现快速衰退。",
      "夜间频繁醒来、踱步或焦躁可能是犬认知功能障碍（CCDS）的信号。",
      "老年犬对食物的敏感性增加，挑食有时是为了规避过敏原。",
      "15岁以上狗狗乱大小便比例激增，多与泌尿系统功能下降有关。",
      "老年犬由于情绪调节能力变弱，常出现严重的‘分离焦虑’。",
      "感官衰退导致社交欲望降低，它可能不再喜欢与其他狗狗互动。",
      "由于反射弧变长，老年犬对呼唤的反应变慢常被误解为‘叛逆’。",
      "视力和听力下降会让狗狗容易受惊，从而引发防御性攻击。"
    ]
  },
  {
    category: "日常护理与观察",
    facts: [
      "健康饮食和适当运动能显著延缓衰老过程，保持状态年轻。",
      "长期缺乏锻炼会加速认知退化，建议保持低强度的精神刺激。",
      "狗狗很少大声喊痛，起身缓慢、步态不稳就是它们在表达不适。",
      "定期洁牙是老年犬护理的重中之重，能有效预防牙周疾病。",
      "大多数宠物保险在10岁后禁购，建议在7岁前完成全面评估。",
      "即便看起来很健康，老年犬内部机能也在随生物钟发生不可逆变化。"
    ]
  }
];

export const SENIOR_KNOWLEDGE_BASE = KNOWLEDGE_THEMES.flatMap(theme => 
  theme.facts.map(fact => ({
    title: theme.category,
    content: fact,
    source: "乖乖狗幼儿园整理自：利物浦大学、罗兰大学、AVMA研究资料"
  }))
);

export const LOG_TYPE_CONFIG = {
  [LogType.VET]: { label: '兽医检查', color: 'bg-blue-100 text-blue-700', icon: '🏥' },
  [LogType.WEIGHT]: { label: '体重记录', color: 'bg-green-100 text-green-700', icon: '⚖️' },
  [LogType.BEHAVIOR]: { label: '异常行为', color: 'bg-orange-100 text-orange-700', icon: '🐕' },
  [LogType.MEDICATION]: { label: '用药提醒', color: 'bg-purple-100 text-purple-700', icon: '💊' },
  [LogType.NOTE]: { label: '日常笔记', color: 'bg-stone-100 text-stone-700', icon: '📝' },
};
